module.exports = {
    TOKEN: 'MTQ4NDUwOTQxMjkyNzIxMzYzOQ.GWEytA.at_WjMO1uii_vC5XN_FUlDAw_CfO1z3uX89LPk',
    BOT_ID: '1459748394867101901',
    GUILD_ID: '1322637122909245440' // Adicione o ID do seu servidor Discord
};
